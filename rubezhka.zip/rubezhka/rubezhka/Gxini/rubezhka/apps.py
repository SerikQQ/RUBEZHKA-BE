from django.apps import AppConfig


class RubezhkaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rubezhka'
