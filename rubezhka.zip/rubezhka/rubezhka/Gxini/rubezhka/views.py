from django.shortcuts import render
from .forms import UserForm
from django.http import HttpResponse, HttpResponseRedirect, HttpResponseNotFound
from .models import User


# Create your views here.

def main(request):
    if request.method == "POST":
        name = request.POST.get("name")
        age = request.POST.get("age")
        user = User(name=name, age=age)
        user.save()
        return HttpResponseRedirect("/")
    else:    
        user_form = UserForm()
        users = User.objects.all()
        return render(request, "main.html", {"form": user_form, "users": users})
    
def edit(request, id):
    try:
        user = User.objects.get(id=id)
        user_form = UserForm()
        if request.method == "POST":
            user.name = request.POST.get("name")
            user.age = request.POST.get("age")
            user.save()
            return HttpResponseRedirect("/")
        else:
            return render(request,"edit.html",{"form": user_form} )
    except User.DoesNotExist:
        return HttpResponseNotFound("<h4>No")
    
def delete(request, id):
    try:
        user = User.objects.get(id=id)
        user.delete()
        return HttpResponseRedirect("/")
    except User.DoesNotExist:
        return HttpResponseNotFound("<h4>No")
